﻿namespace Marcantel_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.customerInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.stateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.phoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.zipMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.streetTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.titlesComboBox = new System.Windows.Forms.ComboBox();
            this.deliveryInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.homeDeliveryRadioButton = new System.Windows.Forms.RadioButton();
            this.storepickupRadioButton = new System.Windows.Forms.RadioButton();
            this.deliveryDateLabel = new System.Windows.Forms.Label();
            this.deliveryDateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.orderDetailsGroupBox = new System.Windows.Forms.GroupBox();
            this.occasionsComboBox = new System.Windows.Forms.ComboBox();
            this.personalMessageTextBox = new System.Windows.Forms.TextBox();
            this.wordLengthLabel = new System.Windows.Forms.Label();
            this.feeMessageLabel = new System.Windows.Forms.Label();
            this.personalMessageCheckBox = new System.Windows.Forms.CheckBox();
            this.extrasLabel = new System.Windows.Forms.Label();
            this.extrasListBox = new System.Windows.Forms.ListBox();
            this.specalOccasionsLabel = new System.Windows.Forms.Label();
            this.pricesLabel = new System.Windows.Forms.Label();
            this.dozenLabel = new System.Windows.Forms.Label();
            this.halfDozenLabel = new System.Windows.Forms.Label();
            this.singleLabel = new System.Windows.Forms.Label();
            this.selectLabel = new System.Windows.Forms.Label();
            this.dozenRadioButton = new System.Windows.Forms.RadioButton();
            this.halfDozenRadioButton = new System.Windows.Forms.RadioButton();
            this.singleRadioButton = new System.Windows.Forms.RadioButton();
            this.orderTotalsGroupBox = new System.Windows.Forms.GroupBox();
            this.totalLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.orderTotalLabel = new System.Windows.Forms.Label();
            this.subtotalLabel = new System.Windows.Forms.Label();
            this.taxAmountLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.displaySummaryButton = new System.Windows.Forms.Button();
            this.clearFormButton = new System.Windows.Forms.Button();
            this.exitProgramButton = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.customerInformationGroupBox.SuspendLayout();
            this.deliveryInformationGroupBox.SuspendLayout();
            this.orderDetailsGroupBox.SuspendLayout();
            this.orderTotalsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(260, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 133);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Romantic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label1.Location = new System.Drawing.Point(294, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bonnie\'s Balloons";
            // 
            // customerInformationGroupBox
            // 
            this.customerInformationGroupBox.Controls.Add(this.stateMaskedTextBox);
            this.customerInformationGroupBox.Controls.Add(this.phoneMaskedTextBox);
            this.customerInformationGroupBox.Controls.Add(this.label8);
            this.customerInformationGroupBox.Controls.Add(this.label2);
            this.customerInformationGroupBox.Controls.Add(this.zipMaskedTextBox);
            this.customerInformationGroupBox.Controls.Add(this.cityTextBox);
            this.customerInformationGroupBox.Controls.Add(this.streetTextBox);
            this.customerInformationGroupBox.Controls.Add(this.lastNameTextBox);
            this.customerInformationGroupBox.Controls.Add(this.firstNameTextBox);
            this.customerInformationGroupBox.Controls.Add(this.label7);
            this.customerInformationGroupBox.Controls.Add(this.label6);
            this.customerInformationGroupBox.Controls.Add(this.label5);
            this.customerInformationGroupBox.Controls.Add(this.label4);
            this.customerInformationGroupBox.Controls.Add(this.label3);
            this.customerInformationGroupBox.Controls.Add(this.titleLabel);
            this.customerInformationGroupBox.Controls.Add(this.titlesComboBox);
            this.customerInformationGroupBox.Location = new System.Drawing.Point(12, 159);
            this.customerInformationGroupBox.Name = "customerInformationGroupBox";
            this.customerInformationGroupBox.Size = new System.Drawing.Size(633, 88);
            this.customerInformationGroupBox.TabIndex = 1;
            this.customerInformationGroupBox.TabStop = false;
            this.customerInformationGroupBox.Text = "Customer Information";
            // 
            // stateMaskedTextBox
            // 
            this.stateMaskedTextBox.Location = new System.Drawing.Point(363, 59);
            this.stateMaskedTextBox.Mask = ">LL";
            this.stateMaskedTextBox.Name = "stateMaskedTextBox";
            this.stateMaskedTextBox.Size = new System.Drawing.Size(18, 20);
            this.stateMaskedTextBox.TabIndex = 11;
            // 
            // phoneMaskedTextBox
            // 
            this.phoneMaskedTextBox.Location = new System.Drawing.Point(538, 59);
            this.phoneMaskedTextBox.Mask = "(999) 000-0000";
            this.phoneMaskedTextBox.Name = "phoneMaskedTextBox";
            this.phoneMaskedTextBox.Size = new System.Drawing.Size(80, 20);
            this.phoneMaskedTextBox.TabIndex = 15;
            this.phoneMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(491, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Phone:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(406, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Zip:";
            // 
            // zipMaskedTextBox
            // 
            this.zipMaskedTextBox.Location = new System.Drawing.Point(437, 59);
            this.zipMaskedTextBox.Mask = "00000";
            this.zipMaskedTextBox.Name = "zipMaskedTextBox";
            this.zipMaskedTextBox.Size = new System.Drawing.Size(35, 20);
            this.zipMaskedTextBox.TabIndex = 13;
            this.zipMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(200, 59);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(89, 20);
            this.cityTextBox.TabIndex = 9;
            // 
            // streetTextBox
            // 
            this.streetTextBox.Location = new System.Drawing.Point(61, 59);
            this.streetTextBox.Name = "streetTextBox";
            this.streetTextBox.Size = new System.Drawing.Size(100, 20);
            this.streetTextBox.TabIndex = 7;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(363, 22);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(89, 20);
            this.lastNameTextBox.TabIndex = 5;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(200, 22);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(89, 20);
            this.firstNameTextBox.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(322, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "State:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(167, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "City:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Street:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(301, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Lastname:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(134, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "First Name:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(25, 25);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Title:";
            // 
            // titlesComboBox
            // 
            this.titlesComboBox.FormattingEnabled = true;
            this.titlesComboBox.Items.AddRange(new object[] {
            "Dr. ",
            "Mr. ",
            "Mrs.",
            "Ms.",
            "Rev."});
            this.titlesComboBox.Location = new System.Drawing.Point(61, 22);
            this.titlesComboBox.Name = "titlesComboBox";
            this.titlesComboBox.Size = new System.Drawing.Size(44, 21);
            this.titlesComboBox.TabIndex = 1;
            // 
            // deliveryInformationGroupBox
            // 
            this.deliveryInformationGroupBox.Controls.Add(this.homeDeliveryRadioButton);
            this.deliveryInformationGroupBox.Controls.Add(this.storepickupRadioButton);
            this.deliveryInformationGroupBox.Controls.Add(this.deliveryDateLabel);
            this.deliveryInformationGroupBox.Controls.Add(this.deliveryDateMaskedTextBox);
            this.deliveryInformationGroupBox.Location = new System.Drawing.Point(12, 253);
            this.deliveryInformationGroupBox.Name = "deliveryInformationGroupBox";
            this.deliveryInformationGroupBox.Size = new System.Drawing.Size(633, 68);
            this.deliveryInformationGroupBox.TabIndex = 2;
            this.deliveryInformationGroupBox.TabStop = false;
            this.deliveryInformationGroupBox.Text = "Delivery Information";
            // 
            // homeDeliveryRadioButton
            // 
            this.homeDeliveryRadioButton.AutoSize = true;
            this.homeDeliveryRadioButton.Location = new System.Drawing.Point(319, 21);
            this.homeDeliveryRadioButton.Name = "homeDeliveryRadioButton";
            this.homeDeliveryRadioButton.Size = new System.Drawing.Size(94, 17);
            this.homeDeliveryRadioButton.TabIndex = 3;
            this.homeDeliveryRadioButton.Text = "Home Delivery";
            this.homeDeliveryRadioButton.UseVisualStyleBackColor = true;
            this.homeDeliveryRadioButton.CheckedChanged += new System.EventHandler(this.homeDeliveryRadioButton_CheckedChanged);
            // 
            // storepickupRadioButton
            // 
            this.storepickupRadioButton.AutoSize = true;
            this.storepickupRadioButton.Location = new System.Drawing.Point(213, 21);
            this.storepickupRadioButton.Name = "storepickupRadioButton";
            this.storepickupRadioButton.Size = new System.Drawing.Size(91, 17);
            this.storepickupRadioButton.TabIndex = 2;
            this.storepickupRadioButton.Text = "Store Pick-Up";
            this.storepickupRadioButton.UseVisualStyleBackColor = true;
            this.storepickupRadioButton.CheckedChanged += new System.EventHandler(this.storepickupRadioButton_CheckedChanged);
            // 
            // deliveryDateLabel
            // 
            this.deliveryDateLabel.AutoSize = true;
            this.deliveryDateLabel.Location = new System.Drawing.Point(8, 23);
            this.deliveryDateLabel.Name = "deliveryDateLabel";
            this.deliveryDateLabel.Size = new System.Drawing.Size(113, 13);
            this.deliveryDateLabel.TabIndex = 0;
            this.deliveryDateLabel.Text = "Desired Delivery Date:";
            // 
            // deliveryDateMaskedTextBox
            // 
            this.deliveryDateMaskedTextBox.Location = new System.Drawing.Point(127, 20);
            this.deliveryDateMaskedTextBox.Mask = "00/00/0000";
            this.deliveryDateMaskedTextBox.Name = "deliveryDateMaskedTextBox";
            this.deliveryDateMaskedTextBox.Size = new System.Drawing.Size(67, 20);
            this.deliveryDateMaskedTextBox.TabIndex = 1;
            this.deliveryDateMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.deliveryDateMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // orderDetailsGroupBox
            // 
            this.orderDetailsGroupBox.Controls.Add(this.occasionsComboBox);
            this.orderDetailsGroupBox.Controls.Add(this.personalMessageTextBox);
            this.orderDetailsGroupBox.Controls.Add(this.wordLengthLabel);
            this.orderDetailsGroupBox.Controls.Add(this.feeMessageLabel);
            this.orderDetailsGroupBox.Controls.Add(this.personalMessageCheckBox);
            this.orderDetailsGroupBox.Controls.Add(this.extrasLabel);
            this.orderDetailsGroupBox.Controls.Add(this.extrasListBox);
            this.orderDetailsGroupBox.Controls.Add(this.specalOccasionsLabel);
            this.orderDetailsGroupBox.Controls.Add(this.pricesLabel);
            this.orderDetailsGroupBox.Controls.Add(this.dozenLabel);
            this.orderDetailsGroupBox.Controls.Add(this.halfDozenLabel);
            this.orderDetailsGroupBox.Controls.Add(this.singleLabel);
            this.orderDetailsGroupBox.Controls.Add(this.selectLabel);
            this.orderDetailsGroupBox.Controls.Add(this.dozenRadioButton);
            this.orderDetailsGroupBox.Controls.Add(this.halfDozenRadioButton);
            this.orderDetailsGroupBox.Controls.Add(this.singleRadioButton);
            this.orderDetailsGroupBox.Location = new System.Drawing.Point(12, 327);
            this.orderDetailsGroupBox.Name = "orderDetailsGroupBox";
            this.orderDetailsGroupBox.Size = new System.Drawing.Size(633, 136);
            this.orderDetailsGroupBox.TabIndex = 3;
            this.orderDetailsGroupBox.TabStop = false;
            this.orderDetailsGroupBox.Text = "Order Details";
            // 
            // occasionsComboBox
            // 
            this.occasionsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.occasionsComboBox.FormattingEnabled = true;
            this.occasionsComboBox.Location = new System.Drawing.Point(200, 39);
            this.occasionsComboBox.Name = "occasionsComboBox";
            this.occasionsComboBox.Size = new System.Drawing.Size(121, 21);
            this.occasionsComboBox.Sorted = true;
            this.occasionsComboBox.TabIndex = 8;
            this.occasionsComboBox.SelectedIndexChanged += new System.EventHandler(this.occasionsComboBox_SelectedIndexChanged);
            // 
            // personalMessageTextBox
            // 
            this.personalMessageTextBox.Enabled = false;
            this.personalMessageTextBox.Location = new System.Drawing.Point(480, 106);
            this.personalMessageTextBox.MaxLength = 30;
            this.personalMessageTextBox.Name = "personalMessageTextBox";
            this.personalMessageTextBox.Size = new System.Drawing.Size(138, 20);
            this.personalMessageTextBox.TabIndex = 14;
            // 
            // wordLengthLabel
            // 
            this.wordLengthLabel.Enabled = false;
            this.wordLengthLabel.Location = new System.Drawing.Point(477, 73);
            this.wordLengthLabel.Name = "wordLengthLabel";
            this.wordLengthLabel.Size = new System.Drawing.Size(141, 30);
            this.wordLengthLabel.TabIndex = 13;
            this.wordLengthLabel.Text = "A maximum length of 30 charecters is allowed:\r\n";
            // 
            // feeMessageLabel
            // 
            this.feeMessageLabel.Location = new System.Drawing.Point(477, 16);
            this.feeMessageLabel.Name = "feeMessageLabel";
            this.feeMessageLabel.Size = new System.Drawing.Size(141, 30);
            this.feeMessageLabel.TabIndex = 11;
            this.feeMessageLabel.Text = "Selecting Personal Message will charge you a $2.50 fee:";
            // 
            // personalMessageCheckBox
            // 
            this.personalMessageCheckBox.AutoSize = true;
            this.personalMessageCheckBox.Location = new System.Drawing.Point(480, 49);
            this.personalMessageCheckBox.Name = "personalMessageCheckBox";
            this.personalMessageCheckBox.Size = new System.Drawing.Size(113, 17);
            this.personalMessageCheckBox.TabIndex = 12;
            this.personalMessageCheckBox.Text = "Personal Message";
            this.personalMessageCheckBox.UseVisualStyleBackColor = true;
            this.personalMessageCheckBox.CheckedChanged += new System.EventHandler(this.personalMessageCheckBox_CheckedChanged);
            // 
            // extrasLabel
            // 
            this.extrasLabel.AutoSize = true;
            this.extrasLabel.Location = new System.Drawing.Point(374, 16);
            this.extrasLabel.Name = "extrasLabel";
            this.extrasLabel.Size = new System.Drawing.Size(39, 13);
            this.extrasLabel.TabIndex = 9;
            this.extrasLabel.Text = "Extras:";
            // 
            // extrasListBox
            // 
            this.extrasListBox.FormattingEnabled = true;
            this.extrasListBox.Location = new System.Drawing.Point(337, 32);
            this.extrasListBox.Name = "extrasListBox";
            this.extrasListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.extrasListBox.Size = new System.Drawing.Size(115, 82);
            this.extrasListBox.Sorted = true;
            this.extrasListBox.TabIndex = 10;
            this.extrasListBox.SelectedIndexChanged += new System.EventHandler(this.extrasListBox_SelectedIndexChanged);
            // 
            // specalOccasionsLabel
            // 
            this.specalOccasionsLabel.AutoSize = true;
            this.specalOccasionsLabel.Location = new System.Drawing.Point(203, 16);
            this.specalOccasionsLabel.Name = "specalOccasionsLabel";
            this.specalOccasionsLabel.Size = new System.Drawing.Size(98, 13);
            this.specalOccasionsLabel.TabIndex = 7;
            this.specalOccasionsLabel.Text = "Special Occasions:";
            // 
            // pricesLabel
            // 
            this.pricesLabel.AutoSize = true;
            this.pricesLabel.Location = new System.Drawing.Point(124, 16);
            this.pricesLabel.Name = "pricesLabel";
            this.pricesLabel.Size = new System.Drawing.Size(39, 13);
            this.pricesLabel.TabIndex = 1;
            this.pricesLabel.Text = "Prices:";
            // 
            // dozenLabel
            // 
            this.dozenLabel.AutoSize = true;
            this.dozenLabel.Location = new System.Drawing.Point(124, 88);
            this.dozenLabel.Name = "dozenLabel";
            this.dozenLabel.Size = new System.Drawing.Size(40, 13);
            this.dozenLabel.TabIndex = 6;
            this.dozenLabel.Text = "$65.95";
            // 
            // halfDozenLabel
            // 
            this.halfDozenLabel.AutoSize = true;
            this.halfDozenLabel.Location = new System.Drawing.Point(124, 65);
            this.halfDozenLabel.Name = "halfDozenLabel";
            this.halfDozenLabel.Size = new System.Drawing.Size(40, 13);
            this.halfDozenLabel.TabIndex = 4;
            this.halfDozenLabel.Tag = "";
            this.halfDozenLabel.Text = "$35.95";
            // 
            // singleLabel
            // 
            this.singleLabel.AutoSize = true;
            this.singleLabel.Location = new System.Drawing.Point(124, 42);
            this.singleLabel.Name = "singleLabel";
            this.singleLabel.Size = new System.Drawing.Size(34, 13);
            this.singleLabel.TabIndex = 2;
            this.singleLabel.Text = "$9.95";
            // 
            // selectLabel
            // 
            this.selectLabel.AutoSize = true;
            this.selectLabel.Location = new System.Drawing.Point(17, 16);
            this.selectLabel.Name = "selectLabel";
            this.selectLabel.Size = new System.Drawing.Size(92, 13);
            this.selectLabel.TabIndex = 0;
            this.selectLabel.Text = "Select an Option: ";
            // 
            // dozenRadioButton
            // 
            this.dozenRadioButton.AutoSize = true;
            this.dozenRadioButton.Location = new System.Drawing.Point(33, 86);
            this.dozenRadioButton.Name = "dozenRadioButton";
            this.dozenRadioButton.Size = new System.Drawing.Size(56, 17);
            this.dozenRadioButton.TabIndex = 5;
            this.dozenRadioButton.Text = "Dozen";
            this.dozenRadioButton.UseVisualStyleBackColor = true;
            this.dozenRadioButton.CheckedChanged += new System.EventHandler(this.dozenRadioButton_CheckedChanged);
            // 
            // halfDozenRadioButton
            // 
            this.halfDozenRadioButton.AutoSize = true;
            this.halfDozenRadioButton.Location = new System.Drawing.Point(33, 63);
            this.halfDozenRadioButton.Name = "halfDozenRadioButton";
            this.halfDozenRadioButton.Size = new System.Drawing.Size(76, 17);
            this.halfDozenRadioButton.TabIndex = 3;
            this.halfDozenRadioButton.Text = "Half-dozen";
            this.halfDozenRadioButton.UseVisualStyleBackColor = true;
            this.halfDozenRadioButton.CheckedChanged += new System.EventHandler(this.halfDozenRadioButton_CheckedChanged);
            // 
            // singleRadioButton
            // 
            this.singleRadioButton.AutoSize = true;
            this.singleRadioButton.Location = new System.Drawing.Point(33, 40);
            this.singleRadioButton.Name = "singleRadioButton";
            this.singleRadioButton.Size = new System.Drawing.Size(54, 17);
            this.singleRadioButton.TabIndex = 1;
            this.singleRadioButton.Text = "Single";
            this.singleRadioButton.UseVisualStyleBackColor = true;
            this.singleRadioButton.CheckedChanged += new System.EventHandler(this.singleRadioButton_CheckedChanged);
            // 
            // orderTotalsGroupBox
            // 
            this.orderTotalsGroupBox.Controls.Add(this.totalLabel);
            this.orderTotalsGroupBox.Controls.Add(this.taxLabel);
            this.orderTotalsGroupBox.Controls.Add(this.orderTotalLabel);
            this.orderTotalsGroupBox.Controls.Add(this.subtotalLabel);
            this.orderTotalsGroupBox.Controls.Add(this.taxAmountLabel);
            this.orderTotalsGroupBox.Controls.Add(this.label9);
            this.orderTotalsGroupBox.Location = new System.Drawing.Point(12, 469);
            this.orderTotalsGroupBox.Name = "orderTotalsGroupBox";
            this.orderTotalsGroupBox.Size = new System.Drawing.Size(633, 100);
            this.orderTotalsGroupBox.TabIndex = 4;
            this.orderTotalsGroupBox.TabStop = false;
            this.orderTotalsGroupBox.Text = "Order Totals";
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(300, 66);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(57, 21);
            this.totalLabel.TabIndex = 5;
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxLabel.Location = new System.Drawing.Point(300, 40);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(57, 21);
            this.taxLabel.TabIndex = 3;
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // orderTotalLabel
            // 
            this.orderTotalLabel.AutoSize = true;
            this.orderTotalLabel.Location = new System.Drawing.Point(226, 67);
            this.orderTotalLabel.Name = "orderTotalLabel";
            this.orderTotalLabel.Size = new System.Drawing.Size(63, 13);
            this.orderTotalLabel.TabIndex = 4;
            this.orderTotalLabel.Text = "Order Total:";
            // 
            // subtotalLabel
            // 
            this.subtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.subtotalLabel.Location = new System.Drawing.Point(300, 15);
            this.subtotalLabel.Name = "subtotalLabel";
            this.subtotalLabel.Size = new System.Drawing.Size(57, 21);
            this.subtotalLabel.TabIndex = 1;
            this.subtotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxAmountLabel
            // 
            this.taxAmountLabel.AutoSize = true;
            this.taxAmountLabel.Location = new System.Drawing.Point(228, 41);
            this.taxAmountLabel.Name = "taxAmountLabel";
            this.taxAmountLabel.Size = new System.Drawing.Size(66, 13);
            this.taxAmountLabel.TabIndex = 2;
            this.taxAmountLabel.Text = "Tax amount:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(245, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Subtotal:";
            // 
            // displaySummaryButton
            // 
            this.displaySummaryButton.Location = new System.Drawing.Point(92, 584);
            this.displaySummaryButton.Name = "displaySummaryButton";
            this.displaySummaryButton.Size = new System.Drawing.Size(114, 23);
            this.displaySummaryButton.TabIndex = 5;
            this.displaySummaryButton.Text = "&Display Summary";
            this.toolTip.SetToolTip(this.displaySummaryButton, "Click this button to display the summary of the data entered.");
            this.displaySummaryButton.UseVisualStyleBackColor = true;
            this.displaySummaryButton.Click += new System.EventHandler(this.displaySummaryButton_Click);
            // 
            // clearFormButton
            // 
            this.clearFormButton.Location = new System.Drawing.Point(294, 584);
            this.clearFormButton.Name = "clearFormButton";
            this.clearFormButton.Size = new System.Drawing.Size(75, 23);
            this.clearFormButton.TabIndex = 6;
            this.clearFormButton.Text = "&Clear Form";
            this.toolTip.SetToolTip(this.clearFormButton, "Click the button to clear the entire form.");
            this.clearFormButton.UseVisualStyleBackColor = true;
            this.clearFormButton.Click += new System.EventHandler(this.clearFormButton_Click);
            // 
            // exitProgramButton
            // 
            this.exitProgramButton.Location = new System.Drawing.Point(469, 584);
            this.exitProgramButton.Name = "exitProgramButton";
            this.exitProgramButton.Size = new System.Drawing.Size(75, 23);
            this.exitProgramButton.TabIndex = 7;
            this.exitProgramButton.Text = "&Exit Program";
            this.toolTip.SetToolTip(this.exitProgramButton, "Click the button to exit out of the program. \r\n");
            this.exitProgramButton.UseVisualStyleBackColor = true;
            this.exitProgramButton.Click += new System.EventHandler(this.exitProgramButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 619);
            this.Controls.Add(this.exitProgramButton);
            this.Controls.Add(this.clearFormButton);
            this.Controls.Add(this.displaySummaryButton);
            this.Controls.Add(this.orderTotalsGroupBox);
            this.Controls.Add(this.orderDetailsGroupBox);
            this.Controls.Add(this.deliveryInformationGroupBox);
            this.Controls.Add(this.customerInformationGroupBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bonnie\'s Balloons";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.customerInformationGroupBox.ResumeLayout(false);
            this.customerInformationGroupBox.PerformLayout();
            this.deliveryInformationGroupBox.ResumeLayout(false);
            this.deliveryInformationGroupBox.PerformLayout();
            this.orderDetailsGroupBox.ResumeLayout(false);
            this.orderDetailsGroupBox.PerformLayout();
            this.orderTotalsGroupBox.ResumeLayout(false);
            this.orderTotalsGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox customerInformationGroupBox;
        private System.Windows.Forms.GroupBox deliveryInformationGroupBox;
        private System.Windows.Forms.GroupBox orderDetailsGroupBox;
        private System.Windows.Forms.ComboBox titlesComboBox;
        private System.Windows.Forms.GroupBox orderTotalsGroupBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox streetTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.MaskedTextBox zipMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox phoneMaskedTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton homeDeliveryRadioButton;
        private System.Windows.Forms.RadioButton storepickupRadioButton;
        private System.Windows.Forms.Label deliveryDateLabel;
        private System.Windows.Forms.MaskedTextBox deliveryDateMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox stateMaskedTextBox;
        private System.Windows.Forms.Label pricesLabel;
        private System.Windows.Forms.Label dozenLabel;
        private System.Windows.Forms.Label halfDozenLabel;
        private System.Windows.Forms.Label singleLabel;
        private System.Windows.Forms.Label selectLabel;
        private System.Windows.Forms.RadioButton dozenRadioButton;
        private System.Windows.Forms.RadioButton halfDozenRadioButton;
        private System.Windows.Forms.RadioButton singleRadioButton;
        private System.Windows.Forms.Button displaySummaryButton;
        private System.Windows.Forms.Button clearFormButton;
        private System.Windows.Forms.Button exitProgramButton;
        private System.Windows.Forms.Label specalOccasionsLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label extrasLabel;
        private System.Windows.Forms.ListBox extrasListBox;
        private System.Windows.Forms.Label feeMessageLabel;
        private System.Windows.Forms.CheckBox personalMessageCheckBox;
        private System.Windows.Forms.Label wordLengthLabel;
        private System.Windows.Forms.TextBox personalMessageTextBox;
        private System.Windows.Forms.ComboBox occasionsComboBox;
        private System.Windows.Forms.Label subtotalLabel;
        private System.Windows.Forms.Label taxAmountLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label orderTotalLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label taxLabel;
    }
}

