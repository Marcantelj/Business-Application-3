﻿// Programmer: Jonathan Marcantel
// Date: 10/31/2018
// Objective: 
// Project: 
using System;
using System.IO;
using System.Windows.Forms;

namespace Marcantel_3
{
    public partial class Form1 : Form
    {
        // Declaring class-level constants that are used throughout the program. 
        private const decimal HOME_DELIVERY_PRICE = 7.50m;
        private const decimal SINGLE_PRICE = 9.95m;
        private const decimal HALF_DOZEN_PRICE = 35.95m;
        private const decimal DOZEN_PRICE = 65.95m;
        private const decimal PERSONAL_MESSAGE_PRICE = 2.50m;
        private const decimal TAX_RATE = .07m;
        private const decimal EXTRAS_PRICE = 9.50m;

        // Declaring class-level variables.
        private decimal subtotal = 0m;
        private decimal salesTax = 0m;
        private decimal total = 0m;
        private string deliveryType = "";
        private string bundleSize = "";
        private string occasion = "";
        private const string extras = "";

        public Form1()
        {
            InitializeComponent();
        }

        // Exicutes all form code at the start of the program.
        // populates all boxes, Updates totals, sets date to today's date, checks single and store pick up to true, and occasions set to "Birthday".
        private void Form1_Load(object sender, EventArgs e)
        {
            populateBoxes();
            deliveryDateMaskedTextBox.Text = DateTime.Now.ToString("MM/dd/yyyy");
            storepickupRadioButton.Checked = true;
            singleRadioButton.Checked = true;
            occasionsComboBox.Text = "Birthday";
            UpdateTotals();
        }

        // populates all boxes so that we are able to see any and all entries with in the combo box and list boxes.
        private void populateBoxes()
        {
            try
            {

                StreamReader inputFile;

                inputFile = File.OpenText("Occasions.txt"); // opens text inside the file.

                // conducted at end of stream
                while (!inputFile.EndOfStream)
                {
                    occasionsComboBox.Items.Add(inputFile.ReadLine()); // Reads the added lines.
                }

                inputFile.Close(); // Closes stream.

                inputFile = File.OpenText("Extras.txt"); // opens text inside the file.

                // conducted at end of stream
                while (!inputFile.EndOfStream)
                {
                    extrasListBox.Items.Add(inputFile.ReadLine()); // Reads the added lines.
                }

                inputFile.Close(); // Closes stream
            }

            // Catches all erros that would occur. 
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }

        }

        // resets all values, all events, and buttons. restets the form back to start position. 
        private void ResetForm()
        {

            titlesComboBox.Text = "";
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            streetTextBox.Text = "";
            cityTextBox.Text = "";
            stateMaskedTextBox.Text = "";
            zipMaskedTextBox.Text = "";
            phoneMaskedTextBox.Text = "";
            storepickupRadioButton.Checked = true;
            singleRadioButton.Checked = true;
            occasionsComboBox.Text = "Birthday";
            extrasListBox.ClearSelected();
            extras = "";
            personalMessageCheckBox.Checked = false;
            subtotal = 0m;
            salesTax = 0m;
            total = 0m;
            UpdateTotals();


        }

        // Updates all totals and all values so that we are able to see what the costomer wants to purchase. 
        // Updates all radio buttons / check boxes / lists. 
        private void UpdateTotals()
        {
            try
            {
                subtotal = 0;
                if (singleRadioButton.Checked)
                {
                    subtotal = subtotal + SINGLE_PRICE;

                }
                else if (halfDozenRadioButton.Checked)
                {
                    subtotal = subtotal + HALF_DOZEN_PRICE;

                }
                else
                {
                    subtotal = subtotal + DOZEN_PRICE;

                }
                if (homeDeliveryRadioButton.Checked)
                {
                    subtotal = subtotal + HOME_DELIVERY_PRICE;
                }
                if (personalMessageCheckBox.Checked)
                {
                    subtotal = subtotal + PERSONAL_MESSAGE_PRICE;
                }
                for (int counter = 0; counter < extrasListBox.Items.Count; counter++)
                {
                    if (extrasListBox.GetSelected(counter))
                    {
                        subtotal = subtotal + EXTRAS_PRICE;
                        extras += extrasListBox.Items[counter] + "\n";
                        
                    }
                }
                subtotalLabel.Text = subtotal.ToString("c2");
                salesTax = subtotal * TAX_RATE;
                taxLabel.Text = salesTax.ToString("c");
                total = subtotal + salesTax;
                totalLabel.Text = total.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }
        }

        // Displays message when you hit display summary that shows all entered values from the program on the message.  
        private void displaySummaryButton_Click(object sender, EventArgs e)
        {
            // Will throw error message if there is no entery for phone, first name, last name.
            if (phoneMaskedTextBox.Text == "" || firstNameTextBox.Text == "" || lastNameTextBox.Text == "")
            {
                MessageBox.Show("You're required to enter something in all of the required fields: Phone Number, First Name, Last Name to continue.",
                    "Information Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            // Message box will show the order summary. 
            else
            {
                MessageBox.Show("Name: " + titlesComboBox.Text + firstNameTextBox.Text + " " + lastNameTextBox.Text + "\n" +
               "Street: " + streetTextBox.Text + "\n" + "City: " + cityTextBox.Text + "\n" + "State: " + stateMaskedTextBox.Text + "\n" + "Zip: "
               + zipMaskedTextBox.Text + "\n" + "Phone: " + phoneMaskedTextBox.Text + "\n" + "Delivery Date: " + deliveryDateMaskedTextBox.Text + "\n"
               + "Delivery Type: " + deliveryType + "\n" + "Bundled Size: " + bundleSize + "\n" + "Special Occasion: " + occasion + "\n"
               + "Extras: \n" + extras + "Message: " + personalMessageTextBox.Text + "\n" + "Order Subtotal Amount: " + subtotalLabel.Text
               + "\n" + "Sales Tax Amount: " + taxLabel.Text + "\n" + "Order Total: " + totalLabel.Text , "Bonnie's Balloons Order Summary" );
            }
        }

        // Closes the program when button is clicked.
        private void exitProgramButton_Click(object sender, EventArgs e)
        {
            // This shows a message if you want to close the application. You choose yes or no. 
            // The if-statement is an exicutible when you hit yes closing the application.
            
                DialogResult selection;
                selection = MessageBox.Show("Are you sure you want to quit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (selection == DialogResult.Yes)
            {
                this.Close();
            }   
        }

        // Updates totals and sets enables and disables word lenth label and personal message text box also resets the text in the box. 
        private void personalMessageCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            // Enables both the label and text box.
            if (personalMessageCheckBox.Checked)
            {
                UpdateTotals();
                wordLengthLabel.Enabled = true;
                personalMessageTextBox.Enabled = true;
            }

            // Clears and unenables the wordlengthlabel and personal message text box. 
            else
            {
                UpdateTotals();
                wordLengthLabel.Enabled = false;
                personalMessageTextBox.Enabled = false;
                personalMessageTextBox.Text = "";
            }
        }

        // sets the deliverytype string = to either store pick up or home delivery. 
        private void storepickupRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // sets the deliverytype string = to store pick up. 
            if (storepickupRadioButton.Checked)
            {
                deliveryType = "Store Pick Up";
            }

            // sets the deliverytype string = to home delivery. 
            else
            {
                deliveryType = "Home Delivery"; 
            }
        }

        // updates totals for event and if box is checked then string for bundle size is = to single.
        private void singleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
            if (singleRadioButton.Checked) 
            {
                bundleSize = "Single";
            }
        }

        // updates totals for event and if box is checked then string for bundle size is = to half-dozen.
        private void halfDozenRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
            if (halfDozenRadioButton.Checked)
            {
                bundleSize = "Half-Dozen";
            }
        }

        // updates totals for event and if box is checked then string for bundle size is = to Dozen.
        private void dozenRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
            if (halfDozenRadioButton.Checked)
            {
                bundleSize = "Dozen";
            }
        }

        // updates totals for event.
        private void homeDeliveryRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        // updates totals for event.
        private void extrasListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        // sets string occasion = to occasionscombobox's selection or text. 
        private void occasionsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            occasion = (occasionsComboBox.Text);
        }

        // When clicked button the program resets back to starting postion. 
        private void clearFormButton_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
    }
}
